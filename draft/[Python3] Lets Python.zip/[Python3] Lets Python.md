
# Let's Python

## 파이썬을 해석할 에디터의 선택

pycharm이 가장 유명한 것 같긴 한데, 그리고 sublime text 도 좋은 것 같은데, 데이터를 다룰 때 제일 좋은 에디터(?)는 Jupyter Notebook이라고 생각한다. Jupyter notebook은 interactive 대화형 interpreter...라고... 아무튼 Anaconda라는 것을 설치하여 이용하는 게 제일 편하고 좋다(특히 Windows에서!).

[Anaconda download](https://www.anaconda.com/download/)

Anaconda는 Python의 버전에 따라 버전이 나뉜다. 현재 Python 2.7과 Python 3.6이 가장 많이 이용되고, 둘 다 써본 결과... 지금 나는 3.6 버전을 이용하고 있다. 3.6으로 바꾸게 된 가장 결정적인 계기는 크롤링 할 때(만약 영문 사이트면 안 그랬겠지만) 한글 encoding에 애먹어서 바꾸게 됐다. 3.6 버전은 한글 encoding 문제에서 비교적 자유롭다. 또한 파이썬 2.7의 목숨은 2020년에 끝난다는데..
그래서 Anaconda는 Python 3.6을 이용하는 버전으로 설치하는 것을 추천한다. (2018년 12월 기준 3.7 버전이 최신)

Anaconda를 통합패키지(?)라고 생각하면 편한데, 중요한 모듈들, 예를 들면 Pandas, Numpy, Scikitlearn, matplotlib, seaborn 등을 포함하고 있기 때문이다. 그래서 따로 다른 모듈을 설치할 필요가 없다 ^^ (물론 없는 것들 혹은 모듈의 버전이 업그레이드 되면, 설치 해주면 된다)

Anaconda를 설치하면, IPython, Spider, Jupyter Notebook 등이 생기는 걸 볼 수 있는데, 이 중에서 주로 Jupyter Notebook을 이용한다(다른 건 잘 안 씀). Jupyter Notebook을 클릭하면, 익스플로러든 크롬이든 열릴 것이다. 그리고 Anaconda가 설치된 폴더가 Home이 되어 해당 폴더에서 ipnyb를 생성해 파이썬을 이용할 수 있다. 이제 써보자.


## Python Module
모듈, R에서는 library다. Python에선 Module이고.

유용한 모듈을 소개하자면

* pandas (R의 dplyr과 비슷하고, data frame을 다루는 모듈)
* numpy (number python? 그래서 "넘파이"라고 부르는데, 숫자를 다루는 모듈)
* matplotlib, seaborn (R에서 ggplot2처럼, plot 그리는 모듈)

등이 있다.


```python
import pandas
```

module을 import 하는 명력어로, Python에서는 module의 일부분만 불러올 수도 있다. 예를 들면, `from pandas import DataFrame, Series` 로 `pandas`에서 `DataFrame`과 `Series`만 불러올 수 있다. 이런 방식으로 `pandas`를 import 하면 `DataFrame`과 `Series` 함수 외의 다른 `pandas`의 함수를 사용할 수 없다. 

module을 import 한 뒤 사용할 때, `pandas`의 `read_csv` 함수를 이용하기 위해 `pandas.read_csv()`를 타이핑해야 한다. 그러나 매번 module의 전체 이름을 쓰기 귀찮으니, `pandas`를 `pd`로 줄여서 `import pandas as pd`로 불러와 `pd.read_csv()`의 형식으로 사용할 수 있다.

참고로 __pandas__ 는 데이터 분석에서 가장 중요하다고 할 수 있는 데이터 전처리에 필요한 매우 중요한 module 중 하나이다. pandas의 tutorial은 [여기](http://pandas.pydata.org/pandas-docs/stable/?v=20170519182642)에서 참고.

## iris data를 이용한 연습

iris 데이터는 연습용 혹은 샘플 데이터로 매우 유명한 데이터이다. 다음의 코드를 이용해 데이터를 웹으로부터 다운로드 받는다. 


```python
import seaborn.apionly as sns
iris = sns.load_dataset('iris')
iris.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
  </tbody>
</table>
</div>



`seaborn`이라는 module에서 제공하는 iris 연습용 데이터를 불러와 `iris.head()` 함수를 이용해 데이터의 상위 5개 행만 보여주고 있다. 

다음은 `.describe()` 함수를 이용해 각 열의 기초통계량을 보여준다. 


```python
iris.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>150.000000</td>
      <td>150.000000</td>
      <td>150.000000</td>
      <td>150.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.843333</td>
      <td>3.057333</td>
      <td>3.758000</td>
      <td>1.199333</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.828066</td>
      <td>0.435866</td>
      <td>1.765298</td>
      <td>0.762238</td>
    </tr>
    <tr>
      <th>min</th>
      <td>4.300000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>0.100000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>5.100000</td>
      <td>2.800000</td>
      <td>1.600000</td>
      <td>0.300000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>5.800000</td>
      <td>3.000000</td>
      <td>4.350000</td>
      <td>1.300000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>6.400000</td>
      <td>3.300000</td>
      <td>5.100000</td>
      <td>1.800000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>7.900000</td>
      <td>4.400000</td>
      <td>6.900000</td>
      <td>2.500000</td>
    </tr>
  </tbody>
</table>
</div>



iris dataframe의 `sepal_length`에 접근하고 싶다면, `iris["sepal_length"]`를 입력하면 된다. 숫자로 접근하기 위해서는 `sepal_length`가 첫 번째 열이기 때문에 `iris.iloc[:, 0]`으로 접근할 수 있다. 


```python
iris["sepal_length"].head()
```




    0    5.1
    1    4.9
    2    4.7
    3    4.6
    4    5.0
    Name: sepal_length, dtype: float64




```python
iris.iloc[:,0].head()
```




    0    5.1
    1    4.9
    2    4.7
    3    4.6
    4    5.0
    Name: sepal_length, dtype: float64



`sepal_length`의 평균을 계산하기 위해서, `iris["sepal_length"].mean()` 함수를 이용할 수 있다.


```python
iris["sepal_length"].mean()
```




    5.843333333333335



소수점 두 자리만 표현하기 위해서 특정 표현식을 사용할 수 있다.


```python
print("Sepal length: %.2f" % (iris["sepal_length"].mean()))
```

    Sepal length: 5.84
    

__조건부 (conditional) 선택__ 도 가능하다. 예를 들면, `species`가 `setosa`인 행만 선택해보자. 조건식에서 __같음__을 표현하기 위해 `=`이 아니라 `==`을 사용한다.


```python
setosa = iris[iris.species == "setosa"]
setosa.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
setosa["species"].unique()
```




    array(['setosa'], dtype=object)



여러 조건에 따라 데이터를 선택할 수도 있다. 

A & B: A 조건과 B 조건을 모두 만족시키는 경우  
A | B: A 조건과 B 조건 중 하나라도 만족시키는 경우


```python
iris[(iris["species"] == "setosa") & (iris["sepal_length"] > 5.0)].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5.4</td>
      <td>3.9</td>
      <td>1.7</td>
      <td>0.4</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>10</th>
      <td>5.4</td>
      <td>3.7</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>14</th>
      <td>5.8</td>
      <td>4.0</td>
      <td>1.2</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>15</th>
      <td>5.7</td>
      <td>4.4</td>
      <td>1.5</td>
      <td>0.4</td>
      <td>setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
iris[(iris["species"] == "setosa") | (iris["sepal_length"] > 5.0)].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>setosa</td>
    </tr>
  </tbody>
</table>
</div>



## seaborn을 이용한 그래프

파이썬에서 그래프를 그릴 수 있는 모듈은 여러 가지가 있다. 대표적으로 `matplotlib.pyplot`, `seaborn`, `ggplot2` 등이 있는데, 여기서는 `seaborn`만 살펴보도록 한다. 


```python
import seaborn as sns
%matplotlib inline 
# 그래프를 셀 안에서 표시하기
```


```python
sns.jointplot(x = setosa.sepal_length, 
              y = setosa.sepal_width,
              kind = "reg")
```

    C:\Users\KYU\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    




    <seaborn.axisgrid.JointGrid at 0x286a3d13898>




![png](output_24_2.png)



```python
sns.jointplot(x = setosa.sepal_length, 
              y = setosa.sepal_width, 
              kind="hex")
```

    C:\Users\KYU\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    




    <seaborn.axisgrid.JointGrid at 0x286a3d56908>




![png](output_25_2.png)



```python
sns.jointplot(x = setosa.sepal_length, 
              y = setosa.sepal_width, 
              kind="kde")
```

    C:\Users\KYU\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    




    <seaborn.axisgrid.JointGrid at 0x286a3c6b0f0>




![png](output_26_2.png)


## IF

`IF` 문은 특정 조건 아래에서 실행 방향을 정해준다.


```python
iris.sepal_length[1], iris.sepal_length[2]
```




    (4.9, 4.7)



첫 번째 `sepal_length`는 `4.9` 이고, 두 번째 `sepal_length`는 `4.7`이다. IF 조건문을 이용해 몇 번째가 더 긴지 살펴보자. 


```python
if iris.sepal_length[1] > iris.sepal_length[2]:
    print("첫 번째 sepal length가 더 길다")
else:
    print("두 번째 sepal length가 더 길다")
```

    첫 번째 sepal length가 더 길다
    

첫 번째 `sepal length`가 더 길다. `if` 문의 첫 번째 문장은 조건이 __참__ 일 때 실행되며, 조건이 __거짓__일 경우 `else` 다음의 문장이 실행된다.

## FOR

`FOR`문은 인덱스를 중심으로 반복적인 작업을 가능하게 한다.   
여기서는 `iris` 데이터에서 `species`가 `setosa`면 `세토사`를, `virginica`면 `버지니카`를 `종` 열에 입력한다. 


```python
iris['species'][i]
```




    'virginica'




```python
iris.loc[1, 'species']
```




    'setosa'




```python
iris["종"] = ""
    
for i in range(len(iris)):                     ## iris데이터를 0부터 149까지 세기(파이썬은 0부터 시작)
    if iris.loc[i, "species"] == "setosa":     ## i번째 species가 'setosa'면
        iris.loc[i, "종"] = "세토사"            ## i번째 종 행에 '세토사'를 입력
    else:                                      ## 그렇지 않으면 (즉, setosa가 아니면)
        iris.loc[i, "종"] = "버지니카"           ## '버지니카'를 입력
        
iris.head(), iris.tail()
```




    (   sepal_length  sepal_width  petal_length  petal_width species    종
     0           5.1          3.5           1.4          0.2  setosa  세토사
     1           4.9          3.0           1.4          0.2  setosa  세토사
     2           4.7          3.2           1.3          0.2  setosa  세토사
     3           4.6          3.1           1.5          0.2  setosa  세토사
     4           5.0          3.6           1.4          0.2  setosa  세토사,
          sepal_length  sepal_width  petal_length  petal_width    species     종
     145           6.7          3.0           5.2          2.3  virginica  버지니카
     146           6.3          2.5           5.0          1.9  virginica  버지니카
     147           6.5          3.0           5.2          2.0  virginica  버지니카
     148           6.2          3.4           5.4          2.3  virginica  버지니카
     149           5.9          3.0           5.1          1.8  virginica  버지니카)


